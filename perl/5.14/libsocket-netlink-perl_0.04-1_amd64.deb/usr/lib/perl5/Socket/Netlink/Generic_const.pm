package Socket::Netlink::Generic;
# This module was generated automatically by ExtUtils::H2PM from lib/Socket/Netlink/Generic_const.pm.PL

use Carp;
push @EXPORT, 'NETLINK_GENERIC', 'pack_genlmsghdr', 'unpack_genlmsghdr', 'CTRL_CMD_UNSPEC', 'CTRL_CMD_NEWFAMILY', 'CTRL_CMD_DELFAMILY', 'CTRL_CMD_GETFAMILY', 'CTRL_CMD_NEWOPS', 'CTRL_CMD_DELOPS', 'CTRL_CMD_GETOPS', 'CTRL_ATTR_UNSPEC', 'CTRL_ATTR_FAMILY_ID', 'CTRL_ATTR_FAMILY_NAME', 'CTRL_CMD_NEWMCAST_GRP', 'CTRL_CMD_DELMCAST_GRP', 'CTRL_CMD_GETMCAST_GRP', 'CTRL_ATTR_VERSION', 'CTRL_ATTR_HDRSIZE', 'CTRL_ATTR_MAXATTR', 'CTRL_ATTR_OPS', 'CTRL_ATTR_MCAST_GROUPS', 'CTRL_ATTR_OP_UNSPEC', 'CTRL_ATTR_OP_ID', 'CTRL_ATTR_OP_FLAGS', 'CTRL_ATTR_MCAST_GRP_UNSPEC', 'CTRL_ATTR_MCAST_GRP_NAME', 'CTRL_ATTR_MCAST_GRP_ID';
use constant NETLINK_GENERIC => 16;

sub pack_genlmsghdr
{
   @_ >= 2 or croak "usage: pack_genlmsghdr(cmd, version, [tail])";
   my @v = @_;
   pack "C C x2a*", @v;
}

sub unpack_genlmsghdr
{
   length $_[0] >= 4 or croak "unpack_genlmsghdr: expected 4 bytes, got " . length $_[0];
   my @v = unpack "C C x2a*", $_[0];
   @v;
}
use constant CTRL_CMD_UNSPEC => 0;
use constant CTRL_CMD_NEWFAMILY => 1;
use constant CTRL_CMD_DELFAMILY => 2;
use constant CTRL_CMD_GETFAMILY => 3;
use constant CTRL_CMD_NEWOPS => 4;
use constant CTRL_CMD_DELOPS => 5;
use constant CTRL_CMD_GETOPS => 6;
use constant CTRL_ATTR_UNSPEC => 0;
use constant CTRL_ATTR_FAMILY_ID => 1;
use constant CTRL_ATTR_FAMILY_NAME => 2;
use constant CTRL_CMD_NEWMCAST_GRP => 7;
use constant CTRL_CMD_DELMCAST_GRP => 8;
use constant CTRL_CMD_GETMCAST_GRP => 9;
use constant CTRL_ATTR_VERSION => 3;
use constant CTRL_ATTR_HDRSIZE => 4;
use constant CTRL_ATTR_MAXATTR => 5;
use constant CTRL_ATTR_OPS => 6;
use constant CTRL_ATTR_MCAST_GROUPS => 7;
use constant CTRL_ATTR_OP_UNSPEC => 0;
use constant CTRL_ATTR_OP_ID => 1;
use constant CTRL_ATTR_OP_FLAGS => 2;
use constant CTRL_ATTR_MCAST_GRP_UNSPEC => 0;
use constant CTRL_ATTR_MCAST_GRP_NAME => 1;
use constant CTRL_ATTR_MCAST_GRP_ID => 2;

1;
