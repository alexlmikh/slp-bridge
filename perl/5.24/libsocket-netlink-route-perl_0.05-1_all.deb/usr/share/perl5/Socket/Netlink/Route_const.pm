package Socket::Netlink::Route;
# This module was generated automatically by ExtUtils::H2PM from lib/Socket/Netlink/Route_const.pm.PL

use Carp;
push @EXPORT, 'NETLINK_ROUTE', 'RTM_NEWLINK', 'RTM_DELLINK', 'RTM_GETLINK', 'RTM_SETLINK', 'pack_ifinfomsg', 'unpack_ifinfomsg', 'IFLA_UNSPEC', 'IFLA_ADDRESS', 'IFLA_BROADCAST', 'IFLA_IFNAME', 'IFLA_MTU', 'IFLA_LINK', 'IFLA_QDISC', 'IFLA_STATS', 'IFLA_COST', 'IFLA_PRIORITY', 'IFLA_MASTER', 'IFLA_WIRELESS', 'IFLA_PROTINFO', 'IFLA_TXQLEN', 'IFLA_MAP', 'IFLA_WEIGHT', 'IFLA_OPERSTATE', 'IFLA_LINKMODE', 'IFLA_LINKINFO', 'IFLA_NET_NS_PID', 'pack_rtnl_link_stats', 'unpack_rtnl_link_stats', 'RTM_NEWADDR', 'RTM_DELADDR', 'RTM_GETADDR', 'pack_ifaddrmsg', 'unpack_ifaddrmsg', 'IFA_UNSPEC', 'IFA_ADDRESS', 'IFA_LOCAL', 'IFA_LABEL', 'IFA_BROADCAST', 'IFA_ANYCAST', 'IFA_CACHEINFO', 'pack_ifa_cacheinfo', 'unpack_ifa_cacheinfo', 'RTM_NEWROUTE', 'RTM_DELROUTE', 'RTM_GETROUTE', 'pack_rtmsg', 'unpack_rtmsg', 'RTN_UNSPEC', 'RTN_UNICAST', 'RTN_LOCAL', 'RTN_BROADCAST', 'RTN_ANYCAST', 'RTN_MULTICAST', 'RTN_BLACKHOLE', 'RTN_UNREACHABLE', 'RTN_PROHIBIT', 'RTN_THROW', 'RTN_NAT', 'RTN_XRESOLVE', 'RTPROT_UNSPEC', 'RTPROT_REDIRECT', 'RTPROT_KERNEL', 'RTPROT_BOOT', 'RTPROT_STATIC', 'RT_SCOPE_UNIVERSE', 'RT_SCOPE_SITE', 'RT_SCOPE_LINK', 'RT_SCOPE_HOST', 'RT_SCOPE_NOWHERE', 'RTM_F_NOTIFY', 'RTM_F_CLONED', 'RTM_F_EQUALIZE', 'RT_TABLE_UNSPEC', 'RT_TABLE_DEFAULT', 'RT_TABLE_MAIN', 'RT_TABLE_LOCAL', 'RTA_UNSPEC', 'RTA_DST', 'RTA_SRC', 'RTA_IIF', 'RTA_OIF', 'RTA_GATEWAY', 'RTA_PRIORITY', 'RTA_PREFSRC', 'RTA_METRICS', 'RTA_MULTIPATH', 'RTA_PROTOINFO', 'RTA_FLOW', 'RTA_CACHEINFO', 'RTM_NEWNEIGH', 'RTM_DELNEIGH', 'RTM_GETNEIGH', 'pack_ndmsg', 'unpack_ndmsg', 'NUD_INCOMPLETE', 'NUD_REACHABLE', 'NUD_STALE', 'NUD_DELAY', 'NUD_PROBE', 'NUD_FAILED', 'NUD_NOARP', 'NUD_PERMANENT', 'NTF_PROXY', 'NTF_ROUTER', 'NDA_UNSPEC', 'NDA_DST', 'NDA_LLADDR', 'NDA_CACHEINFO', 'pack_nda_cacheinfo', 'unpack_nda_cacheinfo', 'RTMGRP_LINK', 'RTMGRP_NOTIFY', 'RTMGRP_NEIGH', 'RTMGRP_TC', 'RTMGRP_IPV4_IFADDR', 'RTMGRP_IPV4_MROUTE', 'RTMGRP_IPV4_ROUTE', 'RTMGRP_IPV4_RULE', 'RTMGRP_IPV6_IFADDR', 'RTMGRP_IPV6_MROUTE', 'RTMGRP_IPV6_ROUTE', 'RTMGRP_IPV6_IFINFO';
use constant NETLINK_ROUTE => 0;
use constant RTM_NEWLINK => 16;
use constant RTM_DELLINK => 17;
use constant RTM_GETLINK => 18;
use constant RTM_SETLINK => 19;

sub pack_ifinfomsg
{
   @_ >= 5 or croak "usage: pack_ifinfomsg(ifi_family, ifi_type, ifi_index, ifi_flags, ifi_change, [tail])";
   my @v = @_;
   pack "C xS l L L a*", @v;
}

sub unpack_ifinfomsg
{
   length $_[0] >= 16 or croak "unpack_ifinfomsg: expected 16 bytes, got " . length $_[0];
   my @v = unpack "C xS l L L a*", $_[0];
   @v;
}
use constant IFLA_UNSPEC => 0;
use constant IFLA_ADDRESS => 1;
use constant IFLA_BROADCAST => 2;
use constant IFLA_IFNAME => 3;
use constant IFLA_MTU => 4;
use constant IFLA_LINK => 5;
use constant IFLA_QDISC => 6;
use constant IFLA_STATS => 7;
use constant IFLA_COST => 8;
use constant IFLA_PRIORITY => 9;
use constant IFLA_MASTER => 10;
use constant IFLA_WIRELESS => 11;
use constant IFLA_PROTINFO => 12;
use constant IFLA_TXQLEN => 13;
use constant IFLA_MAP => 14;
use constant IFLA_WEIGHT => 15;
use constant IFLA_OPERSTATE => 16;
use constant IFLA_LINKMODE => 17;
use constant IFLA_LINKINFO => 18;
use constant IFLA_NET_NS_PID => 19;

sub pack_rtnl_link_stats
{
   ref($_[0]) eq "HASH" or croak "usage: pack_rtnl_link_stats(\%args)";
   my @v = @{$_[0]}{'rx_packets', 'tx_packets', 'rx_bytes', 'tx_bytes', 'rx_errors', 'tx_errors', 'rx_dropped', 'tx_dropped', 'multicast', 'collisions', 'rx_length_errors', 'rx_over_errors', 'rx_crc_errors', 'rx_frame_errors', 'rx_fifo_errors', 'rx_missed_errors', 'tx_aborted_errors', 'tx_carrier_errors', 'tx_fifo_errors', 'tx_heartbeat_errors', 'tx_window_errors', 'rx_compressed', 'tx_compressed'};
   pack "L L L L L L L L L L L L L L L L L L L L L L L x4", @v;
}

sub unpack_rtnl_link_stats
{
   length $_[0] == 96 or croak "unpack_rtnl_link_stats: expected 96 bytes, got " . length $_[0];
   my @v = unpack "L L L L L L L L L L L L L L L L L L L L L L L x4", $_[0];
   my %ret; @ret{'rx_packets', 'tx_packets', 'rx_bytes', 'tx_bytes', 'rx_errors', 'tx_errors', 'rx_dropped', 'tx_dropped', 'multicast', 'collisions', 'rx_length_errors', 'rx_over_errors', 'rx_crc_errors', 'rx_frame_errors', 'rx_fifo_errors', 'rx_missed_errors', 'tx_aborted_errors', 'tx_carrier_errors', 'tx_fifo_errors', 'tx_heartbeat_errors', 'tx_window_errors', 'rx_compressed', 'tx_compressed'} = @v;
   \%ret;
}
use constant RTM_NEWADDR => 20;
use constant RTM_DELADDR => 21;
use constant RTM_GETADDR => 22;

sub pack_ifaddrmsg
{
   @_ >= 5 or croak "usage: pack_ifaddrmsg(ifa_family, ifa_prefixlen, ifa_flags, ifa_scope, ifa_index, [tail])";
   my @v = @_;
   pack "C C C C L a*", @v;
}

sub unpack_ifaddrmsg
{
   length $_[0] >= 8 or croak "unpack_ifaddrmsg: expected 8 bytes, got " . length $_[0];
   my @v = unpack "C C C C L a*", $_[0];
   @v;
}
use constant IFA_UNSPEC => 0;
use constant IFA_ADDRESS => 1;
use constant IFA_LOCAL => 2;
use constant IFA_LABEL => 3;
use constant IFA_BROADCAST => 4;
use constant IFA_ANYCAST => 5;
use constant IFA_CACHEINFO => 6;

sub pack_ifa_cacheinfo
{
   ref($_[0]) eq "HASH" or croak "usage: pack_ifa_cacheinfo(\%args)";
   my @v = @{$_[0]}{'ifa_prefered', 'ifa_valid', 'cstamp', 'tstamp'};
   pack "L L L L ", @v;
}

sub unpack_ifa_cacheinfo
{
   length $_[0] == 16 or croak "unpack_ifa_cacheinfo: expected 16 bytes, got " . length $_[0];
   my @v = unpack "L L L L ", $_[0];
   my %ret; @ret{'ifa_prefered', 'ifa_valid', 'cstamp', 'tstamp'} = @v;
   \%ret;
}
use constant RTM_NEWROUTE => 24;
use constant RTM_DELROUTE => 25;
use constant RTM_GETROUTE => 26;

sub pack_rtmsg
{
   @_ >= 9 or croak "usage: pack_rtmsg(rtm_family, rtm_dst_len, rtm_src_len, rtm_tos, rtm_table, rtm_protocol, rtm_scope, rtm_type, rtm_flags, [tail])";
   my @v = @_;
   pack "C C C C C C C C L a*", @v;
}

sub unpack_rtmsg
{
   length $_[0] >= 12 or croak "unpack_rtmsg: expected 12 bytes, got " . length $_[0];
   my @v = unpack "C C C C C C C C L a*", $_[0];
   @v;
}
use constant RTN_UNSPEC => 0;
use constant RTN_UNICAST => 1;
use constant RTN_LOCAL => 2;
use constant RTN_BROADCAST => 3;
use constant RTN_ANYCAST => 4;
use constant RTN_MULTICAST => 5;
use constant RTN_BLACKHOLE => 6;
use constant RTN_UNREACHABLE => 7;
use constant RTN_PROHIBIT => 8;
use constant RTN_THROW => 9;
use constant RTN_NAT => 10;
use constant RTN_XRESOLVE => 11;
use constant RTPROT_UNSPEC => 0;
use constant RTPROT_REDIRECT => 1;
use constant RTPROT_KERNEL => 2;
use constant RTPROT_BOOT => 3;
use constant RTPROT_STATIC => 4;
use constant RT_SCOPE_UNIVERSE => 0;
use constant RT_SCOPE_SITE => 200;
use constant RT_SCOPE_LINK => 253;
use constant RT_SCOPE_HOST => 254;
use constant RT_SCOPE_NOWHERE => 255;
use constant RTM_F_NOTIFY => 256;
use constant RTM_F_CLONED => 512;
use constant RTM_F_EQUALIZE => 1024;
use constant RT_TABLE_UNSPEC => 0;
use constant RT_TABLE_DEFAULT => 253;
use constant RT_TABLE_MAIN => 254;
use constant RT_TABLE_LOCAL => 255;
use constant RTA_UNSPEC => 0;
use constant RTA_DST => 1;
use constant RTA_SRC => 2;
use constant RTA_IIF => 3;
use constant RTA_OIF => 4;
use constant RTA_GATEWAY => 5;
use constant RTA_PRIORITY => 6;
use constant RTA_PREFSRC => 7;
use constant RTA_METRICS => 8;
use constant RTA_MULTIPATH => 9;
use constant RTA_PROTOINFO => 10;
use constant RTA_FLOW => 11;
use constant RTA_CACHEINFO => 12;
use constant RTM_NEWNEIGH => 28;
use constant RTM_DELNEIGH => 29;
use constant RTM_GETNEIGH => 30;

sub pack_ndmsg
{
   @_ >= 5 or croak "usage: pack_ndmsg(ndm_family, ndm_ifindex, ndm_state, ndm_flags, ndm_type, [tail])";
   my @v = @_;
   pack "C xxxl S C C a*", @v;
}

sub unpack_ndmsg
{
   length $_[0] >= 12 or croak "unpack_ndmsg: expected 12 bytes, got " . length $_[0];
   my @v = unpack "C xxxl S C C a*", $_[0];
   @v;
}
use constant NUD_INCOMPLETE => 1;
use constant NUD_REACHABLE => 2;
use constant NUD_STALE => 4;
use constant NUD_DELAY => 8;
use constant NUD_PROBE => 16;
use constant NUD_FAILED => 32;
use constant NUD_NOARP => 64;
use constant NUD_PERMANENT => 128;
use constant NTF_PROXY => 8;
use constant NTF_ROUTER => 128;
use constant NDA_UNSPEC => 0;
use constant NDA_DST => 1;
use constant NDA_LLADDR => 2;
use constant NDA_CACHEINFO => 3;

sub pack_nda_cacheinfo
{
   ref($_[0]) eq "HASH" or croak "usage: pack_nda_cacheinfo(\%args)";
   my @v = @{$_[0]}{'ndm_confirmed', 'ndm_used', 'ndm_updated', 'ndm_refcnt'};
   pack "L L L L ", @v;
}

sub unpack_nda_cacheinfo
{
   length $_[0] == 16 or croak "unpack_nda_cacheinfo: expected 16 bytes, got " . length $_[0];
   my @v = unpack "L L L L ", $_[0];
   my %ret; @ret{'ndm_confirmed', 'ndm_used', 'ndm_updated', 'ndm_refcnt'} = @v;
   \%ret;
}
use constant RTMGRP_LINK => 1;
use constant RTMGRP_NOTIFY => 2;
use constant RTMGRP_NEIGH => 4;
use constant RTMGRP_TC => 8;
use constant RTMGRP_IPV4_IFADDR => 16;
use constant RTMGRP_IPV4_MROUTE => 32;
use constant RTMGRP_IPV4_ROUTE => 64;
use constant RTMGRP_IPV4_RULE => 128;
use constant RTMGRP_IPV6_IFADDR => 256;
use constant RTMGRP_IPV6_MROUTE => 512;
use constant RTMGRP_IPV6_ROUTE => 1024;
use constant RTMGRP_IPV6_IFINFO => 2048;

1;
